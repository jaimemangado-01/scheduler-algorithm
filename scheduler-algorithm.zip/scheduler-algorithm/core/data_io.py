import pandas as pd
import numpy as np
from typing import Tuple, Optional, Dict, Any, List
from dataclasses import dataclass
from datetime import datetime

# Configuration constants
MIN_SHIFT_HOURS = 2
MIN_REST_HOURS_BETWEEN_SHIFTS = 0
NUM_DAYS = 7
SLOTS_PER_DAY = 48
TOTAL_SLOTS = NUM_DAYS * SLOTS_PER_DAY
DAY_NAMES = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday']

@dataclass
class ValidationResult:
    """Results of data validation."""
    success: bool
    errors: List[str]
    warnings: List[str]
    summary: Dict[str, Any]

def slot_to_time(slot_index: int) -> str:
    """Convierte un índice de slot (0-48) a formato HH:MM."""
    if slot_index == SLOTS_PER_DAY: 
        return "00:00"
    hour = slot_index // 2
    minute = (slot_index % 2) * 30
    return f"{hour:02d}:{minute:02d}"

def validate_and_parse_riders(riders_df: pd.DataFrame) -> ValidationResult:
    """Valida y procesa los datos de riders."""
    errors = []
    warnings = []
    summary = {}
    
    try:
        # Create a copy to avoid modifying the original
        df = riders_df.copy()
        
        # Check required columns
        required_columns = ['rider_id', 'weekly_hours', 'max_daily_hours']
        missing_columns = [col for col in required_columns if col not in df.columns]
        if missing_columns:
            errors.append(f"Missing required columns: {missing_columns}")
            return ValidationResult(False, errors, warnings, summary)
        
        # Clean and validate rider_id
        df.dropna(subset=['rider_id'], inplace=True)
        df['rider_id'] = df['rider_id'].astype(str)
        duplicates = df[df.duplicated(subset=['rider_id'], keep=False)]
        if not duplicates.empty:
            errors.append(f"Duplicate rider IDs found: {duplicates['rider_id'].tolist()}")
            return ValidationResult(False, errors, warnings, summary)
        
        # Validate numeric columns
        df['weekly_hours'] = pd.to_numeric(df['weekly_hours'], errors='coerce')
        df['max_daily_hours'] = pd.to_numeric(df['max_daily_hours'], errors='coerce')
        
        # Check for invalid numeric values
        invalid_weekly = df['weekly_hours'].isna().sum()
        invalid_daily = df['max_daily_hours'].isna().sum()
        if invalid_weekly > 0 or invalid_daily > 0:
            errors.append(f"Invalid numeric values: weekly_hours ({invalid_weekly}), max_daily_hours ({invalid_daily})")
            return ValidationResult(False, errors, warnings, summary)
        
        df.dropna(subset=['weekly_hours', 'max_daily_hours'], inplace=True)
        
        # Handle optional columns
        df['preferred_rest_days'] = df['preferred_rest_days'].fillna('')
        if 'acepta_madrugada' in df.columns:
            df['acepta_madrugada'] = df['acepta_madrugada'].fillna(False).astype(bool)
        else:
            warnings.append("Column 'acepta_madrugada' not found. Assuming no riders accept early morning shifts.")
            df['acepta_madrugada'] = False
        
        # Business logic validation
        for index, row in df.iterrows():
            rider_id, weekly_h, daily_max_h = row['rider_id'], row['weekly_hours'], row['max_daily_hours']
            
            # Calculate working days
            dias_a_trabajar = 5
            if weekly_h > 0:
                max_dias_posibles = int(weekly_h // MIN_SHIFT_HOURS)
                if max_dias_posibles < 5:
                    dias_a_trabajar = max_dias_posibles
            else:
                dias_a_trabajar = 0
            
            if dias_a_trabajar == 0 and weekly_h > 0:
                errors.append(f"Rider {rider_id}: Has {weekly_h}h weekly but cannot work any days with {MIN_SHIFT_HOURS}h minimum shifts")
                continue
            
            # Check capacity constraints
            capacidad_maxima = dias_a_trabajar * daily_max_h
            if weekly_h > capacidad_maxima:
                errors.append(f"Rider {rider_id}: Weekly hours ({weekly_h}) exceed maximum capacity ({capacidad_maxima})")
            
            capacidad_minima = dias_a_trabajar * MIN_SHIFT_HOURS
            if weekly_h < capacidad_minima:
                errors.append(f"Rider {rider_id}: Weekly hours ({weekly_h}) below minimum capacity ({capacidad_minima})")
        
        if errors:
            return ValidationResult(False, errors, warnings, summary)
        
        # Create summary
        summary = {
            'total_riders': len(df),
            'total_weekly_hours': df['weekly_hours'].sum(),
            'avg_weekly_hours': df['weekly_hours'].mean(),
            'riders_accepting_early_shifts': df['acepta_madrugada'].sum()
        }
        
        return ValidationResult(True, errors, warnings, summary)
        
    except Exception as e:
        errors.append(f"Unexpected error during riders validation: {str(e)}")
        return ValidationResult(False, errors, warnings, summary)

def validate_and_parse_demand(demand_df: pd.DataFrame) -> ValidationResult:
    """Valida y procesa los datos de demanda."""
    errors = []
    warnings = []
    summary = {}
    
    try:
        # Create a copy to avoid modifying the original
        df = demand_df.copy()
        
        # Check for demand column
        demand_col_name = None
        if 'rider_demand' in df.columns:
            demand_col_name = 'rider_demand'
        elif 'riders_needed' in df.columns:
            demand_col_name = 'riders_needed'
        else:
            errors.append("No demand column found. Must be named 'rider_demand' or 'riders_needed'")
            return ValidationResult(False, errors, warnings, summary)
        
        # Check required columns
        required_columns = ['codigo_ciudad', 'day_of_week', demand_col_name]
        if 'time' not in df.columns and 'slot_30min' not in df.columns:
            required_columns.append('time or slot_30min')
        
        missing_columns = [col for col in required_columns if col not in df.columns and col != 'time or slot_30min']
        if missing_columns:
            errors.append(f"Missing required columns: {missing_columns}")
            return ValidationResult(False, errors, warnings, summary)
        
        # Validate demand values
        df[demand_col_name] = pd.to_numeric(df[demand_col_name], errors='coerce')
        rows_before = len(df)
        df.dropna(subset=[demand_col_name], inplace=True)
        rows_after = len(df)
        
        if rows_after < rows_before:
            warnings.append(f"Removed {rows_before - rows_after} rows with invalid demand values")
        
        # Validate date format
        try:
            df['parsed_date'] = pd.to_datetime(df['day_of_week'], format='%d/%m/%Y')
        except Exception as e:
            errors.append(f"Invalid date format in 'day_of_week'. Expected 'DD/MM/YYYY': {str(e)}")
            return ValidationResult(False, errors, warnings, summary)
        
        # Check time slots
        time_col = 'time' if 'time' in df.columns else 'slot_30min'
        df[time_col] = pd.to_numeric(df[time_col], errors='coerce')
        invalid_slots = df[df[time_col].isna() | (df[time_col] < 1) | (df[time_col] > SLOTS_PER_DAY)]
        if not invalid_slots.empty:
            errors.append(f"Invalid time slots found. Must be between 1 and {SLOTS_PER_DAY}")
            return ValidationResult(False, errors, warnings, summary)
        
        # Create summary
        total_demand = df[demand_col_name].sum()
        avg_demand = df[demand_col_name].mean()
        unique_cities = df['codigo_ciudad'].nunique()
        unique_days = df['parsed_date'].nunique()
        
        summary = {
            'total_demand': int(total_demand),
            'average_demand_per_slot': round(avg_demand, 2),
            'unique_cities': unique_cities,
            'unique_days': unique_days,
            'date_range': f"{df['parsed_date'].min().strftime('%d/%m/%Y')} to {df['parsed_date'].max().strftime('%d/%m/%Y')}",
            'demand_column': demand_col_name
        }
        
        return ValidationResult(True, errors, warnings, summary)
        
    except Exception as e:
        errors.append(f"Unexpected error during demand validation: {str(e)}")
        return ValidationResult(False, errors, warnings, summary)

def process_demand_data(demand_df: pd.DataFrame) -> Tuple[np.ndarray, str, Dict[int, str]]:
    """Procesa los datos de demanda y devuelve arrays estructurados."""
    # Determine demand column
    demand_col_name = 'rider_demand' if 'rider_demand' in demand_df.columns else 'riders_needed'
    time_col = 'time' if 'time' in demand_df.columns else 'slot_30min'
    
    # Initialize demand array
    demand_array = np.zeros(TOTAL_SLOTS, dtype=int)
    city_code = demand_df['codigo_ciudad'].iloc[0]
    date_map = {}
    
    # Parse dates
    demand_df['parsed_date'] = pd.to_datetime(demand_df['day_of_week'], format='%d/%m/%Y')
    
    # Fill demand array
    for _, row in demand_df.iterrows():
        day_index = row['parsed_date'].weekday()
        date_str = row['day_of_week']
        
        if day_index not in date_map:
            date_map[day_index] = date_str
        
        slot_index = int(row[time_col]) - 1  # Convert to 0-based index
        demand_value = row[demand_col_name]
        global_index = day_index * SLOTS_PER_DAY + slot_index
        demand_array[global_index] = int(demand_value)
    
    return demand_array, city_code, date_map

def process_riders_data(riders_df: pd.DataFrame) -> Dict[str, Dict[str, Any]]:
    """Procesa los datos de riders y devuelve diccionario estructurado."""
    return riders_df.set_index('rider_id').to_dict('index')