import numpy as np
from typing import Dict, Any, Optional, Callable, Tuple, List
from dataclasses import dataclass
import time
from .optimizer_core import (
    build_optimization_model, create_objective, solve_model,
    OptimizationResult
)
from .data_io import slot_to_time

@dataclass
class OptimizationConfig:
    """Configuration for optimization process."""
    seed_time_limit: int = 20
    main_time_limit: int = 600
    undersupply_penalty_multiplier: float = 1.0
    oversupply_penalty_multiplier: float = 2.0

@dataclass
class ScheduleEntry:
    """Single schedule entry."""
    city_code: str
    rider_id: str
    date: str
    start_time: str
    end_time: str
    action: str = "BOOK"

class OptimizationOrchestrator:
    """Orchestrates the two-phase optimization process."""
    
    def __init__(self, config: OptimizationConfig):
        self.config = config
        self.progress_callback = None
        self.cancel_token = {"cancel": False}
    
    def set_progress_callback(self, callback: Callable[[str, int, float, float], None]):
        """Set callback for progress updates. Callback receives: (phase, solution_num, time, penalty)"""
        self.progress_callback = callback
    
    def set_cancel_token(self, cancel_token: Dict[str, bool]):
        """Set cancel token to allow interruption of optimization."""
        self.cancel_token = cancel_token
    
    def generate_heuristic_seed(self, riders: Dict, demand: np.ndarray, 
                              city_code: str, date_map: Dict[int, str]) -> Optional[Dict]:
        """Phase 1: Generate heuristic seed solution."""
        def seed_callback(solution_num: int, wall_time: float, penalty: float):
            if self.progress_callback:
                self.progress_callback("seed", solution_num, wall_time, penalty)
        
        # Build model with forced rules for faster initial solution
        model, x, aux_vars = build_optimization_model(riders, demand, use_forced_rules=True)
        create_objective(model, x, riders, demand, 
                        self.config.undersupply_penalty_multiplier,
                        self.config.oversupply_penalty_multiplier,
                        use_hierarchical_penalties=False)  # Simple penalties for seed
        
        # Solve with time limit
        result = solve_model(model, x, riders, self.config.seed_time_limit, 
                           seed_callback, self.cancel_token)
        
        if result.success:
            # Extract solution as dictionary
            solution_dict = {}
            for r in riders:
                for d in range(7):
                    for s in range(48):
                        if (r, d, s) in x:
                            # This would need actual solver values, but for now return structure
                            solution_dict[(r, d, s)] = 0  # Placeholder
            return solution_dict
        
        return None
    
    def run_main_optimization(self, riders: Dict, demand: np.ndarray, 
                            city_code: str, date_map: Dict[int, str],
                            warm_start_solution: Optional[Dict] = None) -> OptimizationResult:
        """Phase 2: Run main optimization with warm start."""
        def main_callback(solution_num: int, wall_time: float, penalty: float):
            if self.progress_callback:
                self.progress_callback("main", solution_num, wall_time, penalty)
        
        # Build model with flexible rules
        model, x, aux_vars = build_optimization_model(riders, demand, use_forced_rules=False)
        create_objective(model, x, riders, demand,
                        self.config.undersupply_penalty_multiplier,
                        self.config.oversupply_penalty_multiplier,
                        use_hierarchical_penalties=True)  # Full penalty system
        
        # Solve with warm start
        result = solve_model(model, x, riders, self.config.main_time_limit,
                           main_callback, self.cancel_token, warm_start_solution)
        
        if result.success:
            # Generate schedule file
            self._save_schedule(x, riders, city_code, date_map, "horario_VEC")
        
        return result
    
    def run_complete_optimization(self, riders: Dict, demand: np.ndarray, 
                                city_code: str, date_map: Dict[int, str]) -> OptimizationResult:
        """Run complete two-phase optimization process."""
        
        # Phase 1: Generate seed
        if self.progress_callback:
            self.progress_callback("seed", 0, 0.0, 0.0)
        
        seed_solution = self.generate_heuristic_seed(riders, demand, city_code, date_map)
        
        if not seed_solution and not self.cancel_token.get("cancel", False):
            # If seed fails, try without warm start
            if self.progress_callback:
                self.progress_callback("main", 0, 0.0, 0.0)
            return self.run_main_optimization(riders, demand, city_code, date_map)
        
        if self.cancel_token.get("cancel", False):
            # Return cancelled result
            return OptimizationResult(False, None, 0, 0.0, "CANCELLED", 0.0)
        
        # Phase 2: Main optimization
        if self.progress_callback:
            self.progress_callback("main", 0, 0.0, 0.0)
        
        return self.run_main_optimization(riders, demand, city_code, date_map, seed_solution)
    
    def _save_schedule(self, x: Dict, riders: Dict, city_code: str, 
                      date_map: Dict[int, str], filename_prefix: str) -> List[ScheduleEntry]:
        """Process and save schedule to CSV format."""
        schedule_entries = []
        
        # This would need access to the actual solver solution
        # For now, return the structure that would be generated
        for r_id in riders.keys():
            for d in range(7):
                # Placeholder logic - would need actual solver values
                working_slots = []  # Would be populated from solver.Value(x[r_id, d, s])
                
                if working_slots:
                    date_str = date_map.get(d, f"Day_{d+1}")
                    
                    # Group consecutive slots into shifts
                    working_slots.sort()
                    start_slot = working_slots[0]
                    
                    for i in range(1, len(working_slots)):
                        if working_slots[i] != working_slots[i-1] + 1:
                            # End of a shift
                            end_slot = working_slots[i-1] + 1
                            entry = ScheduleEntry(
                                city_code=city_code,
                                rider_id=r_id,
                                date=date_str,
                                start_time=slot_to_time(start_slot),
                                end_time=slot_to_time(end_slot)
                            )
                            schedule_entries.append(entry)
                            start_slot = working_slots[i]
                    
                    # Add final shift
                    end_slot = working_slots[-1] + 1
                    entry = ScheduleEntry(
                        city_code=city_code,
                        rider_id=r_id,
                        date=date_str,
                        start_time=slot_to_time(start_slot),
                        end_time=slot_to_time(end_slot)
                    )
                    schedule_entries.append(entry)
        
        # Save to CSV
        if schedule_entries:
            import pandas as pd
            df_data = [
                {
                    'codigo_ciudad': entry.city_code,
                    'courier_ID': entry.rider_id,
                    'dia': entry.date,
                    'hora_inicio': entry.start_time,
                    'hora_final': entry.end_time,
                    'accion': entry.action
                }
                for entry in schedule_entries
            ]
            df = pd.DataFrame(df_data)
            df.to_csv(f"outputs/{filename_prefix}.csv", index=False)
        
        return schedule_entries
    
    def cancel_optimization(self):
        """Cancel the current optimization process."""
        self.cancel_token["cancel"] = True