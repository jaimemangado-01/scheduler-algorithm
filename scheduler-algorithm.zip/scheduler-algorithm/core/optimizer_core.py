import numpy as np
from ortools.sat.python import cp_model
from typing import Dict, Any, Tuple, Callable, Optional
from dataclasses import dataclass
from .data_io import NUM_DAYS, SLOTS_PER_DAY, TOTAL_SLOTS, MIN_SHIFT_HOURS, MIN_REST_HOURS_BETWEEN_SHIFTS, DAY_NAMES

@dataclass
class OptimizationResult:
    """Results from optimization."""
    success: bool
    assigned_array: Optional[np.ndarray]
    solution_count: int
    final_penalty: float
    solver_status: str
    execution_time: float

class SolutionMonitorCallback(cp_model.CpSolverSolutionCallback):
    """Callback class that monitors optimization progress and provides real-time updates."""
    
    def __init__(self, progress_callback: Optional[Callable[[int, float, float], None]] = None, 
                 cancel_token: Optional[Dict[str, bool]] = None):
        cp_model.CpSolverSolutionCallback.__init__(self)
        self.__solution_count = 0
        self.progress_callback = progress_callback
        self.cancel_token = cancel_token or {}
    
    def on_solution_callback(self):
        """Called when a new solution is found."""
        self.__solution_count += 1
        wall_time = self.WallTime()
        penalty = self.ObjectiveValue()
        
        # Send progress update if callback provided
        if self.progress_callback:
            self.progress_callback(self.__solution_count, wall_time, penalty)
        
        # Check for cancellation
        if self.cancel_token.get('cancel', False):
            self.StopSearch()
    
    def solution_count(self) -> int:
        return self.__solution_count

def apply_weekly_hours(model: cp_model.CpModel, x: Dict, riders: Dict, aux_vars: Dict) -> Tuple[cp_model.CpModel, Dict]:
    """Apply weekly hours constraints."""
    for r_id, r_info in riders.items():
        weekly_slots = int(r_info['weekly_hours'] * 2)
        model.Add(sum(x[r_id, d, s] for d in range(NUM_DAYS) for s in range(SLOTS_PER_DAY)) == weekly_slots)
    return model, aux_vars

def apply_daily_max_hours(model: cp_model.CpModel, x: Dict, riders: Dict, aux_vars: Dict) -> Tuple[cp_model.CpModel, Dict]:
    """Apply daily maximum hours constraints."""
    for r_id, r_info in riders.items():
        max_slots_diarios = int(r_info['max_daily_hours'] * 2)
        for d in range(NUM_DAYS):
            model.Add(sum(x[r_id, d, s] for s in range(SLOTS_PER_DAY)) <= max_slots_diarios)
    return model, aux_vars

def apply_rest_and_work_day_rules(model: cp_model.CpModel, x: Dict, riders: Dict, aux_vars: Dict) -> Tuple[cp_model.CpModel, Dict]:
    """Apply rest and work day rules (flexible version)."""
    y = {(r_id, d): model.NewBoolVar(f'y_{r_id}_{d}') for r_id in riders.keys() for d in range(NUM_DAYS)}
    day_abbr_to_index = {name[:3]: i for i, name in enumerate(DAY_NAMES)}
    
    for r_id, r_info in riders.items():
        dias_a_trabajar = 5
        max_dias_posibles = int(r_info['weekly_hours'] // MIN_SHIFT_HOURS)
        if max_dias_posibles < 5:
            dias_a_trabajar = max_dias_posibles
        
        model.Add(sum(y[r_id, d] for d in range(NUM_DAYS)) == dias_a_trabajar)
        
        # Handle preferred rest days
        preferred_days_str = r_info.get('preferred_rest_days', '')
        if isinstance(preferred_days_str, str) and '-' in preferred_days_str:
            day1_abbr, day2_abbr = preferred_days_str.split('-')
            d1_idx, d2_idx = day_abbr_to_index.get(day1_abbr), day_abbr_to_index.get(day2_abbr)
            if d1_idx is not None and d2_idx is not None:
                model.Add(y[r_id, d1_idx] == 0)
                model.Add(y[r_id, d2_idx] == 0)
        else:
            # Ensure consecutive rest days when no preference specified
            dias_de_descanso = NUM_DAYS - dias_a_trabajar
            if dias_de_descanso >= 2:
                pares_consecutivos = [(d, d + 1) for d in range(NUM_DAYS - 1)]
                condiciones = []
                for d1, d2 in pares_consecutivos:
                    es_par_de_descanso = model.NewBoolVar(f'descanso_{r_id}_{d1}_{d2}')
                    condiciones.append(es_par_de_descanso)
                    model.AddBoolAnd([y[r_id, d1].Not(), y[r_id, d2].Not()]).OnlyEnforceIf(es_par_de_descanso)
                    model.AddImplication(es_par_de_descanso, y[r_id, d1].Not())
                    model.AddImplication(es_par_de_descanso, y[r_id, d2].Not())
                model.Add(sum(condiciones) >= 1)
        
        # Link work days to shifts
        for d in range(NUM_DAYS):
            model.Add(sum(x[r_id, d, s] for s in range(SLOTS_PER_DAY)) > 0).OnlyEnforceIf(y[r_id, d])
            model.Add(sum(x[r_id, d, s] for s in range(SLOTS_PER_DAY)) == 0).OnlyEnforceIf(y[r_id, d].Not())
    
    aux_vars["y"] = y
    return model, aux_vars

def apply_rest_and_work_day_rules_forced(model: cp_model.CpModel, x: Dict, riders: Dict, 
                                        demand: np.ndarray, aux_vars: Dict) -> Tuple[cp_model.CpModel, Dict]:
    """Apply rest and work day rules using demand-based intelligent assignment (forced version)."""
    y = {(r_id, d): model.NewBoolVar(f'y_{r_id}_{d}') for r_id in riders.keys() for d in range(NUM_DAYS)}
    day_abbr_to_index = {name[:3]: i for i, name in enumerate(DAY_NAMES)}
    num_total_riders = len(riders)
    total_rest_days_to_assign = num_total_riders * 2

    # Calculate demand pressure per day
    demand_slots_per_day = [sum(demand[d * SLOTS_PER_DAY : (d + 1) * SLOTS_PER_DAY]) for d in range(NUM_DAYS)]
    total_weekly_demand_slots = sum(demand_slots_per_day) if sum(demand_slots_per_day) > 0 else 1
    day_pressure = [demand_slots / total_weekly_demand_slots for demand_slots in demand_slots_per_day]

    # Calculate rest attractiveness (lower demand = more attractive for rest)
    rest_attractiveness = [(1 - pressure) for pressure in day_pressure]
    total_attractiveness = sum(rest_attractiveness) if sum(rest_attractiveness) > 0 else 1

    # Distribute rest days based on attractiveness
    target_resting_riders_per_day = [(att / total_attractiveness) * total_rest_days_to_assign 
                                   for att in rest_attractiveness]

    pares_consecutivos = [(d, d + 1) for d in range(NUM_DAYS - 1)]
    rest_assignments = {pair: [] for pair in pares_consecutivos}
    rider_to_rest_pair = {}

    # Pre-assign riders with preferences
    riders_sin_preferencias = list(riders.keys())
    for r_id in list(riders_sin_preferencias):
        r_info = riders[r_id]
        pref_str = r_info.get('preferred_rest_days', '')
        if isinstance(pref_str, str) and '-' in pref_str:
            d1_abbr, d2_abbr = pref_str.split('-')
            d1, d2 = day_abbr_to_index.get(d1_abbr), day_abbr_to_index.get(d2_abbr)
            if d1 is not None and d2 is not None and (d1, d2) in rest_assignments:
                rest_assignments[(d1, d2)].append(r_id)
                rider_to_rest_pair[r_id] = (d1, d2)
                riders_sin_preferencias.remove(r_id)

    # Assign remaining riders based on demand
    for r_id in riders_sin_preferencias:
        bucket_need = {}
        for d1, d2 in pares_consecutivos:
            target = (target_resting_riders_per_day[d1] + target_resting_riders_per_day[d2]) / 2
            need = target - len(rest_assignments.get((d1, d2), []))
            bucket_need[(d1, d2)] = max(0, need)
        
        if bucket_need:
            best_pair = max(bucket_need, key=bucket_need.get)
            rest_assignments[best_pair].append(r_id)
            rider_to_rest_pair[r_id] = best_pair

    # Apply constraints
    for r_id, r_info in riders.items():
        dias_a_trabajar = 5
        if r_info['weekly_hours'] > 0:
            max_dias_posibles = int(r_info['weekly_hours'] // MIN_SHIFT_HOURS)
            if max_dias_posibles < 5:
                dias_a_trabajar = max_dias_posibles
        else:
            dias_a_trabajar = 0
        
        model.Add(sum(y[r_id, d] for d in range(NUM_DAYS)) == dias_a_trabajar)
        
        if r_id in rider_to_rest_pair:
            d1, d2 = rider_to_rest_pair[r_id]
            model.Add(y[r_id, d1] == 0)
            model.Add(y[r_id, d2] == 0)
        else:
            if dias_a_trabajar == 0:
                for d in range(NUM_DAYS):
                    model.Add(y[r_id, d] == 0)
            else:
                model.Add(sum(y[r_id, d].Not() for d in range(NUM_DAYS)) == (NUM_DAYS - dias_a_trabajar))
        
        # Link work days to shifts
        for d in range(NUM_DAYS):
            model.Add(sum(x[r_id, d, s] for s in range(SLOTS_PER_DAY)) > 0).OnlyEnforceIf(y[r_id, d])
            model.Add(sum(x[r_id, d, s] for s in range(SLOTS_PER_DAY)) == 0).OnlyEnforceIf(y[r_id, d].Not())

    aux_vars["y"] = y
    return model, aux_vars

def apply_night_shift_preferences(model: cp_model.CpModel, x: Dict, riders: Dict, aux_vars: Dict) -> Tuple[cp_model.CpModel, Dict]:
    """Apply night shift preferences (prohibit early morning work for those who don't accept it)."""
    night_slots = [s for s in range(0, 7 * 2)]  # 00:00 to 07:00
    for r_id, r_info in riders.items():
        if not r_info.get('acepta_madrugada', False):
            for d in range(NUM_DAYS):
                for s in night_slots:
                    model.Add(x[r_id, d, s] == 0)
    return model, aux_vars

def apply_daily_shift_structure_rules(model: cp_model.CpModel, x: Dict, riders: Dict, aux_vars: Dict) -> Tuple[cp_model.CpModel, Dict]:
    """Apply shift structure rules to ensure proper shift lengths."""
    for r_id in riders.keys():
        for d in range(NUM_DAYS):
            # Prevent very short shifts
            for s in range(SLOTS_PER_DAY):
                # Prohibit R-T-R (0.5h shift)
                if s > 0 and s < SLOTS_PER_DAY - 1:
                    model.AddBoolOr([x[r_id, d, s - 1], x[r_id, d, s].Not(), x[r_id, d, s + 1]])
                # Prohibit R-T-T-R (1h shift)
                if s > 0 and s < SLOTS_PER_DAY - 2:
                    model.AddBoolOr([x[r_id, d, s - 1], x[r_id, d, s].Not(), 
                                   x[r_id, d, s + 1].Not(), x[r_id, d, s + 2]])
                # Prohibit R-T-T-T-R (1.5h shift)
                if s > 0 and s < SLOTS_PER_DAY - 3:
                    model.AddBoolOr([x[r_id, d, s - 1], x[r_id, d, s].Not(), 
                                   x[r_id, d, s + 1].Not(), x[r_id, d, s + 2].Not(), x[r_id, d, s + 3]])
            
            # Limit number of shift starts per day
            starts = [model.NewBoolVar(f'start_{r_id}_{d}_{s}') for s in range(SLOTS_PER_DAY)]
            model.Add(starts[0] == x[r_id, d, 0])
            for s in range(1, SLOTS_PER_DAY):
                model.Add(starts[s] == 1).OnlyEnforceIf(x[r_id, d, s]).OnlyEnforceIf(x[r_id, d, s-1].Not())
                model.Add(starts[s] == 0).OnlyEnforceIf(x[r_id, d, s].Not())
                model.Add(starts[s] == 0).OnlyEnforceIf(x[r_id, d, s-1])
            model.Add(sum(starts) <= 2)  # Maximum 2 shifts per day
            
            # Prevent isolated single slots
            for s in range(1, SLOTS_PER_DAY - 1):
                model.AddBoolOr([x[r_id, d, s - 1].Not(), x[r_id, d, s], x[r_id, d, s + 1].Not()])
    
    return model, aux_vars

def apply_final_time_rules(model: cp_model.CpModel, x: Dict, riders: Dict, 
                          aux_vars: Dict, demand: np.ndarray) -> Tuple[cp_model.CpModel, Dict]:
    """Apply final timing rules including zero-demand slots and rest periods."""
    # Don't assign riders to zero-demand slots
    for i in range(TOTAL_SLOTS):
        if demand[i] == 0:
            d = i // SLOTS_PER_DAY
            s = i % SLOTS_PER_DAY
            for r_id in riders.keys():
                model.Add(x[r_id, d, s] == 0)
    
    # Apply minimum rest hours between shifts
    slots_de_descanso = int(MIN_REST_HOURS_BETWEEN_SHIFTS * 2)
    if slots_de_descanso > 0:
        for r_id in riders.keys():
            for d in range(NUM_DAYS):
                for s in range(SLOTS_PER_DAY):
                    for i in range(1, slots_de_descanso):
                        next_s_raw = s + i
                        day_offset = next_s_raw // SLOTS_PER_DAY
                        if d + day_offset >= NUM_DAYS:
                            continue
                        next_s = next_s_raw % SLOTS_PER_DAY
                        next_d = d + day_offset
                        model.AddBoolOr([x[r_id, d, s].Not(), x[r_id, next_d, next_s].Not()])
    
    return model, aux_vars

def build_optimization_model(riders: Dict, demand: np.ndarray, use_forced_rules: bool = False) -> Tuple[cp_model.CpModel, Dict, Dict]:
    """Build the complete optimization model."""
    model = cp_model.CpModel()
    
    # Decision variables: x[rider_id, day, slot] = 1 if rider works that slot
    x = {(r, d, s): model.NewBoolVar(f'x_{r}_{d}_{s}') 
         for r in riders.keys() 
         for d in range(NUM_DAYS) 
         for s in range(SLOTS_PER_DAY)}
    
    # Apply constraints
    aux_vars = {"y": None}
    model, aux_vars = apply_weekly_hours(model, x, riders, aux_vars)
    model, aux_vars = apply_daily_max_hours(model, x, riders, aux_vars)
    
    if use_forced_rules:
        model, aux_vars = apply_rest_and_work_day_rules_forced(model, x, riders, demand, aux_vars)
    else:
        model, aux_vars = apply_rest_and_work_day_rules(model, x, riders, aux_vars)
    
    model, aux_vars = apply_night_shift_preferences(model, x, riders, aux_vars)
    model, aux_vars = apply_daily_shift_structure_rules(model, x, riders, aux_vars)
    model, aux_vars = apply_final_time_rules(model, x, riders, aux_vars, demand)
    
    return model, x, aux_vars

def create_objective(model: cp_model.CpModel, x: Dict, riders: Dict, demand: np.ndarray, 
                    undersupply_multiplier: float = 1.0, oversupply_multiplier: float = 2.0,
                    use_hierarchical_penalties: bool = True) -> None:
    """Create the optimization objective with penalty system."""
    assigned_per_slot = [sum(x[r, d, s] for r in riders.keys()) 
                        for d in range(NUM_DAYS) for s in range(SLOTS_PER_DAY)]
    
    faltan = [model.NewIntVar(0, len(riders), f'faltan_{i}') for i in range(TOTAL_SLOTS)]
    sobran = [model.NewIntVar(0, len(riders), f'sobran_{i}') for i in range(TOTAL_SLOTS)]
    
    for i in range(TOTAL_SLOTS):
        model.Add(assigned_per_slot[i] + faltan[i] - sobran[i] == int(demand[i]))
    
    if use_hierarchical_penalties:
        # Create hierarchical penalty system
        day_multipliers_faltan = [1.0, 1.1, 1.2, 1.5, 2.5, 2.8, 3.0]
        penalty_weights_faltan = np.ones(TOTAL_SLOTS)
        
        for d in range(NUM_DAYS):
            for s in range(SLOTS_PER_DAY):
                # Time-based penalties
                if s >= 20*2 and s < 23*2: base_weight = 100  # Dinner
                elif s >= 13*2 and s < 15*2: base_weight = 80  # Lunch
                elif (s >= 15*2 and s < 20*2) or (s >= 23*2 and s < 24*2): base_weight = 40  # Afternoon/Late
                elif s >= 7*2 and s < 13*2: base_weight = 30  # Morning
                else: base_weight = 10  # Early morning
                penalty_weights_faltan[d * SLOTS_PER_DAY + s] = base_weight * day_multipliers_faltan[d]
        
        day_multipliers_sobran = [5.0, 2.8, 2.5, 2.0, 1.8, 1.5, 1.2]
        penalty_weights_sobran = np.ones(TOTAL_SLOTS)
        
        for d in range(NUM_DAYS):
            for s in range(SLOTS_PER_DAY):
                if s >= 20*2 and s < 23*2: base_weight = 20  # Dinner
                elif s >= 13*2 and s < 15*2: base_weight = 20  # Lunch
                elif (s >= 15*2 and s < 20*2) or (s >= 23*2 and s < 24*2): base_weight = 50  # Afternoon/Late
                elif s >= 7*2 and s < 13*2: base_weight = 80  # Morning
                else: base_weight = 100  # Early morning
                penalty_weights_sobran[d * SLOTS_PER_DAY + s] = base_weight * day_multipliers_sobran[d]
        
        penalizacion_total_faltan = sum(faltan[i] * undersupply_multiplier * penalty_weights_faltan[i] 
                                      for i in range(TOTAL_SLOTS))
        penalizacion_total_sobran = sum(sobran[i] * oversupply_multiplier * penalty_weights_sobran[i] 
                                      for i in range(TOTAL_SLOTS))
    else:
        # Simple penalty system for seed generation
        penalizacion_total_faltan = sum(faltan[i] * 1.5 for i in range(TOTAL_SLOTS))
        penalizacion_total_sobran = sum(sobran[i] for i in range(TOTAL_SLOTS))
    
    model.Minimize(penalizacion_total_faltan + penalizacion_total_sobran)

def solve_model(model: cp_model.CpModel, x: Dict, riders: Dict, time_limit: int, 
                progress_callback: Optional[Callable[[int, float, float], None]] = None,
                cancel_token: Optional[Dict[str, bool]] = None,
                warm_start_solution: Optional[Dict] = None) -> OptimizationResult:
    """Solve the optimization model."""
    solver = cp_model.CpSolver()
    solver.parameters.max_time_in_seconds = time_limit
    
    # Add warm start if provided
    if warm_start_solution:
        for (r, d, s), val in warm_start_solution.items():
            if val == 1 and (r, d, s) in x:
                model.AddHint(x[r, d, s], 1)
    
    # Set up callback
    callback = SolutionMonitorCallback(progress_callback, cancel_token)
    
    # Solve
    import time
    start_time = time.time()
    status = solver.Solve(model, callback)
    execution_time = time.time() - start_time
    
    # Process results
    success = status in [cp_model.OPTIMAL, cp_model.FEASIBLE]
    assigned_array = None
    final_penalty = 0.0
    
    if success:
        assigned_array = np.array([sum(solver.Value(x[r, d, s]) for r in riders.keys()) 
                                 for d in range(NUM_DAYS) for s in range(SLOTS_PER_DAY)])
        final_penalty = solver.ObjectiveValue()
    
    return OptimizationResult(
        success=success,
        assigned_array=assigned_array,
        solution_count=callback.solution_count(),
        final_penalty=final_penalty,
        solver_status=str(status),
        execution_time=execution_time
    )